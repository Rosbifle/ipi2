var indexSectionsWithContent =
{
  0: "acefgimprs",
  1: "eg",
  2: "gm",
  3: "acfiprs",
  4: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Typedefs"
};

