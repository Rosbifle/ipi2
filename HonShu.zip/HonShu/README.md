# ipi2
Projet IPI S2

J'ai créé une branch 'developing' sur laquelle on taffe. on travaille sur developing et on ne push/commit sur le master que quand ça marche.
